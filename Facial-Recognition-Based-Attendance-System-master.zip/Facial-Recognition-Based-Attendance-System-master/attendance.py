import pandas as pd
a=pd.read_excel('Attendance.xlsx')
print(a)