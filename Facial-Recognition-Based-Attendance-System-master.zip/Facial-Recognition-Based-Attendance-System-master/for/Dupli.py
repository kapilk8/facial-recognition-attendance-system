from shutil import copyfile
src = r'Temp.xlsx'
dst = r'Attendance.xlsx'
copyfile(src, dst)

