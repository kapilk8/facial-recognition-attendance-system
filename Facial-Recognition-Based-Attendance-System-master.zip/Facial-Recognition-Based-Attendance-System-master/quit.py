import cv2

class release:
	
	cv2.destroyAllWindows() 


